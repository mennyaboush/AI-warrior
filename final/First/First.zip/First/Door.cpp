#include "Door.h"

Door::Door(Room& current, Room& destination): current(current), destination(destination)
{
}

Door::~Door()
{
}

